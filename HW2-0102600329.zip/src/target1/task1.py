import asyncio
import aiohttp
import time
import json
import numpy as np
import pandas as pd
from transformers import AutoTokenizer

# ===== 配置 =====
SERVER = "http://localhost:30000"
MODEL_PATH = "/root/Qwen3-0.6B"
NUM_REQUESTS = 32
MAX_CONCURRENCY = 8
SHARED_PREFIX_LEN = 2048
SUFFIX_LEN = 64
TOTAL_LEN = 2112

# ===== 读取文本并编码 =====
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)

with open("text.txt", "r", encoding="utf-8") as f:
    text = f.read()

all_tokens = tokenizer.encode(text)
print(f"文本编码后共 {len(all_tokens)} 个 token")

# 共享前缀：取前 2048 个 token
shared_prefix = all_tokens[:SHARED_PREFIX_LEN]

# ===== 构造两组 input_ids =====
def build_shared_prefix_group():
    """共享前缀组：2048 相同前缀 + 64 个不同后缀"""
    requests = []
    for i in range(NUM_REQUESTS):
        # 用不同位置的 token 作为后缀，确保每条不同
        start = SHARED_PREFIX_LEN + i * SUFFIX_LEN
        suffix = all_tokens[start:start + SUFFIX_LEN]
        if len(suffix) < SUFFIX_LEN:
            suffix = suffix + [0] * (SUFFIX_LEN - len(suffix))
        input_ids = shared_prefix + suffix
        requests.append(input_ids)
    return requests

def build_dispersed_prefix_group():
    """分散前缀组：每条 2112 token，首 token 各不相同"""
    requests = []
    for i in range(NUM_REQUESTS):
        # 首 token 用不同的 id
        first_token = 1000 + i
        # 后面用相同填充
        rest = all_tokens[:TOTAL_LEN - 1]
        input_ids = [first_token] + rest
        requests.append(input_ids)
    return requests

# ===== 流式请求 =====
async def send_request(session, input_ids, semaphore, results, idx):
    async with semaphore:
        payload = {
            "input_ids": input_ids,
            "sampling_params": {
                "temperature": 0,
                "max_new_tokens": 16,
                "ignore_eos": True,
                "sampling_seed": 2026
            },
            "stream": True
        }
        start_time = time.time()
        ttft = None
        last_chunk_time = None
        completion_tokens = 0
        cached_tokens = 0
        prompt_tokens = 0
        e2e_latency = None

        try:
            async with session.post(f"{SERVER}/generate", json=payload) as resp:
                async for line in resp.content:
                    line = line.decode("utf-8").strip()
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str == "[DONE]":
                        break
                    data = json.loads(data_str)

                    if ttft is None:
                        ttft = time.time() - start_time

                    meta = data.get("meta_info", {})
                    completion_tokens = meta.get("completion_tokens", 0)
                    cached_tokens = meta.get("cached_tokens", 0)
                    prompt_tokens = meta.get("prompt_tokens", 0)

                    if meta.get("finish_reason") is not None:
                        e2e_latency = meta.get("e2e_latency", time.time() - start_time)

            latency = time.time() - start_time
            tpot = (e2e_latency - ttft) / max(completion_tokens - 1, 1) if e2e_latency and ttft else None

            results.append({
                "index": idx,
                "prompt_tokens": prompt_tokens,
                "cached_tokens": cached_tokens,
                "completion_tokens": completion_tokens,
                "ttft": ttft,
                "tpot": tpot,
                "e2e_latency": e2e_latency,
                "status": "success"
            })
        except Exception as e:
            results.append({
                "index": idx,
                "status": f"error: {str(e)}"
            })

# ===== 主流程 =====
async def run_group(group_name, input_ids_list):
    print(f"\n===== 运行 {group_name} =====")

    async with aiohttp.ClientSession() as session:
        # 1. flush cache
        async with session.post(f"{SERVER}/flush_cache") as resp:
            print(f"flush_cache: {await resp.text()}")

        # 2. 共享前缀组先预热
        if group_name == "shared_prefix":
            warmup_payload = {
                "input_ids": input_ids_list[0],
                "sampling_params": {"temperature": 0, "max_new_tokens": 4, "ignore_eos": True}
            }
            async with session.post(f"{SERVER}/generate", json=warmup_payload) as resp:
                await resp.json()
            print("预热请求完成")

        # 3. 并发发送
        semaphore = asyncio.Semaphore(MAX_CONCURRENCY)
        results = []
        tasks = [
            send_request(session, input_ids, semaphore, results, i)
            for i, input_ids in enumerate(input_ids_list)
        ]
        await asyncio.gather(*tasks)

    # 4. 汇总
    df = pd.DataFrame(results)
    df.to_csv(f"results_{group_name}.csv", index=False)

    success = df[df["status"] == "success"]
    print(f"\n{group_name} 汇总：")
    print(f"成功率: {len(success)}/{len(df)}")
    if len(success) > 0:
        print(f"总 prompt_tokens: {success['prompt_tokens'].sum()}")
        print(f"总 cached_tokens: {success['cached_tokens'].sum()}")
        print(f"缓存命中率: {success['cached_tokens'].sum() / success['prompt_tokens'].sum():.4f}")
        print(f"实际 Prefill tokens: {success['prompt_tokens'].sum() - success['cached_tokens'].sum()}")
        print(f"TTFT p50: {np.percentile(success['ttft'].dropna(), 50):.4f}")
        print(f"TTFT p95: {np.percentile(success['ttft'].dropna(), 95):.4f}")
        print(f"TPOT p50: {np.percentile(success['tpot'].dropna(), 50):.6f}")
        print(f"TPOT p95: {np.percentile(success['tpot'].dropna(), 95):.6f}")
        print(f"e2e_latency p50: {np.percentile(success['e2e_latency'].dropna(), 50):.4f}")
        print(f"e2e_latency p95: {np.percentile(success['e2e_latency'].dropna(), 95):.4f}")

    return df

async def main():
    # 共享前缀组
    shared_group = build_shared_prefix_group()
    await run_group("shared_prefix", shared_group)

    # 分散前缀组
    dispersed_group = build_dispersed_prefix_group()
    await run_group("dispersed_prefix", dispersed_group)

if __name__ == "__main__":
    asyncio.run(main())