```markdown
# HW2-付佳杰

## 环境
GPU:RTX 5060(8GB)
系统: windows11 +WSL2(Ubuntu 24.04)
SGLang 0.5.20 Ray 2.56.0 Qwen3-0.6B
说明:因CUDA13驱动问题无法使用 0.5.14 改用 0.5.20

## 安装
```bash
python3 -m venv ~/sglang-env
source ~/sglang-env/bin/activate
pip install "sglang==0.5.20" "ray==2.56.0"
pip install aiohttp transformers pandas numpy
```

## 启动
```bash
python -m sglang.launch_server --model-path /root/Qwen3-0.6B --host 0.0.0.0 --port 30000 --mem-fraction-static 0.6
```

## 回放
```bash
python3 src/target1/task1.py
```

## 结果
报告中的表	               原始文件
任务一对照表（共享前缀组）	results/target1/shared_prefix/results_shared_prefix.csv
任务一对照表（分散前缀组）	results/target1/dispersed_prefix/results_dispersed_prefix.csv